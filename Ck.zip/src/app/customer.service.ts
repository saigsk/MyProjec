import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  public isUserLogged:boolean;

  constructor(public httpClient:HttpClient) {
    this.isUserLogged=false;

   }
   public setUserLoggedIn():void{
    this.isUserLogged=true;
   }
   public getUserLoggedIn():any{
    return this.isUserLogged;
   }
   public setUserLoggedOut():void{
     this.isUserLogged=false;
   }
   public register(customer:any): any{
    return this.httpClient.post('registerCustomer',customer);
   }

   public getCustomer(loginId:any,password:any):any{
     return this.httpClient.get('getCustomer'+'/'+loginId+'/'+password);
   }

   public getallcustomers(): any{
     return this.httpClient.get('showAllCustomers')
   }
}
