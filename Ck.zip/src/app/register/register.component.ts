import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  
  constructor(public router:Router,public service:CustomerService) { }

  ngOnInit(): void {
  }
  submitRegisterForm(registerForm:any):void{
    alert("register button clicked !!");
   
    console.log(registerForm);
    this.service.register(registerForm).subscribe((result:any)=>console.log(result));
    this.router.navigate(['login']);

    

  }
  loginPage():void{
    this.router.navigate(['login']);

  }

}
