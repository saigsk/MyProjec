import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  message:any;
  loginId:any;
  password:any;
   customer:any;

  constructor(public router:Router,public service:CustomerService) { 
    this.loginId='';
    this.password='';
    this.customer='';
    // console.log(this.loginId+"   "+this.password)
   
  }

  ngOnInit(): void {
  }
    async submitLoginForm(loginFrom:any){

    // alert("Login Button Clicked");
    //console.log(loginFrom);

    if(loginFrom.loginId==="admin" && loginFrom.password==="admin"){
      this.service.setUserLoggedIn();
      this.router.navigate(['adminheader']);
    } else{
      await this.service.getCustomer(loginFrom.loginId,loginFrom.password).toPromise().then((data:any)=>{console.log(data);this.customer=data;});
      if(this.customer)
      {
        alert("Login Successes !! ");
        console.log(this.customer);
          this.service.setUserLoggedIn();
          this.router.navigate(['recipe']);
      }
      else{
        alert("Login Failed !! ");
        this.router.navigate(['register']);
      }
    }
    

  }

  registerPage():void{
    this.router.navigate(['register']);

  }

}
