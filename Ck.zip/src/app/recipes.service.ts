import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RecipesService {

  constructor(public httpClient: HttpClient) {


   }

public getInstructions(): any{
  this.httpClient.get("/getinstructions");
}

}
