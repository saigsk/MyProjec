import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HeaderComponent } from './header/header.component';
import { RouterModule,Routes } from '@angular/router';
import { FooterComponent } from './footer/footer.component';
import { RecipeComponent } from './recipe/recipe.component';
import { AuthGuard } from './auth.guard';
import{HttpClientModule} from '@angular/common/http';
import { AdminheaderComponent } from './adminheader/adminheader.component';
import { ShowallcustomersComponent } from './showallcustomers/showallcustomers.component';
const appRoot:Routes=[
  {path:'',component:LoginComponent},
  {path:'login',component:LoginComponent},
  {path:'register',component:RegisterComponent},
  {path:'recipe',canActivate:[AuthGuard],component:RecipeComponent},
  {path:'adminheader',canActivate:[AuthGuard],component:AdminheaderComponent},
  {path:'adminheader/showallcustomers',canActivate:[AuthGuard],component:ShowallcustomersComponent}
  

];

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    HeaderComponent,
    FooterComponent,
    RecipeComponent,
    AdminheaderComponent,
    ShowallcustomersComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot(appRoot),
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
