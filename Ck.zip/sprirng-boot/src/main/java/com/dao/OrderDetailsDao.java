package com.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.OrderDetails;

@Service
public class OrderDetailsDao {
	
	@Autowired
	OrderDetailsRepository ordersDetailsRepository;

	public void register(OrderDetails orderDetails) {
		ordersDetailsRepository.save(orderDetails);
		
	}
	

}
