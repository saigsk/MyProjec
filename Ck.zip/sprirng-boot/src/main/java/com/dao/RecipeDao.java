package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Recipe;

@Service
public class RecipeDao {

	@Autowired
	RecipeRepository recipeRepository;
	
	public void registerRecipe(Recipe recipe) {
		
		recipeRepository.save(recipe);
	}

	public Recipe getRecipeById(int recipeId) {
		
		return recipeRepository.findById(recipeId).orElse(new Recipe());
	}

	public List<Recipe> getAllRecipes() {
		
		return recipeRepository.findAll();
	}

	

}
