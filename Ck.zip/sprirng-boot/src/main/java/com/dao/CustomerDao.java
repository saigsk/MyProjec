package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Customer;
import com.model.Employee;

@Service
public class CustomerDao {
	
	@Autowired
	CustomerRepository customerRepository;

	
	  public void register1(Customer customer) {
	  
	  customerRepository.save(customer);
	  
	  }
	 
	public List<Customer> getAllCustomers() {
		
		return customerRepository.findAll();
	}

	public  void register(Customer customer) {
		
		System.out.println("employee data receieved from employee controller");
		customerRepository.save(customer);
		
	}

	public Customer getCustomer(String loginId, String password) {
		Customer customer= customerRepository.findByLoginIdAndPassword(loginId,password);
		return customer;
		
	}

}
