package com.ts;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dao.CustomerDao;
import com.model.Customer;
import com.model.Employee;

@RestController
public class CustomerController {

	@Autowired
	CustomerDao customerDao;

	@RequestMapping("/registerCus")
	public void register1(Customer customer) {
		Customer c1 = new Customer("sai", "9063216349", "9-60", "Ganesh Nagar", "miryalaguda", "sai123", "password");
		Customer c2 = new Customer("mahindar", "906573473", "1-4-3", "ramanthapur", "hyderabad", "mahi123", "password");

		customerDao.register1(c1);
		customerDao.register1(c2);

	}

	@PostMapping("/registerCustomer")
	public void registerCustomer(@RequestBody Customer customer) {
		System.out.println("Data Received from Angular for Register customer");
		System.out.println(customer);
		
		
		
		customerDao.register(customer);
		
	}
	@RequestMapping("/getCustomer/{loginId}/{password}")
	public Customer getEmp(@PathVariable("loginId") String loginId, @PathVariable("password") String password) {
		Customer customer = customerDao.getCustomer(loginId, password);
		return customer;
	}

	@RequestMapping("/showAllCustomers")
	public List<Customer> showAllCustomers() {
		List<Customer> custList = customerDao.getAllCustomers();
		return custList;

	}

}
