package com.ts;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dao.IngredientDao;
import com.dao.RecipeDao;
import com.model.Ingredient;
import com.model.Recipe;

@RestController
public class RecipeController {

	@Autowired
	RecipeDao recipeDao;


	@Autowired
	IngredientDao ingredientDao;

	@RequestMapping("/registerRecipe")
	public void registerRecipe(Recipe recipe) {

		List<Ingredient> ingredientList = ingredientDao.getAllIngredients();
	

		Recipe r1 = new Recipe("Aloo fry", "1 step:  Peel the potatoes and cut them into cube size "
				+ "2 step: heat a pan with oil add mustard, cumin ,chop garlic  and curry leaves  after  1 min  add potatoes and turmeric ",
				"3 step: fry for 3-4 mins then add  red chili powder  and garam masala"
						+ "4 step: mix  and fry  for  few more mintues , till the chill powder blends well with potatoes."
						+ "5 step: serve Aloo fry with rice and rasam",
				180.84, ingredientList.get(0));

		Recipe r2 = new Recipe("chicken noodles",
				"step 1 : boil the noodles and chicken in seprate pot  for 10 mins. drain and keep aside"
						+ "step 2: heat oil  in deep frying pan and saute the onions and garlic util it turns golden then add chicken and mix well",
				"step 3: Add red chilli sauce, soy sauce  and noodles. cook for 3-5 mins" + "step 4: serve hot",
				280.84, ingredientList.get(1));

		Recipe r3 = new Recipe("dal",
				"step 1: In pressure  cook add 3/4 cup toor dal and  3 cups water  for 5 whistles."
						+ "step 2: now in another kadai heat add oil, mustard seeds  1 spoon jeera , fried chilli and few curry leaves and pinch of hing",
				"step 3: add  in cooker ginger garlic paste ,  green chills , turmeric, chill powder ,coriander powder saute on low flame"
						+ "step 4: additionally add 1 tomato cook it till it turn soft cook it for 5-10 min. then add oil which prepared at step 2",
				120.84, ingredientList.get(2));
		Recipe r4 = new Recipe("fried rice", "step 1: heat the oil in a pan and saute the  veggies  until it turns soft"
				+ "step 2: add chill sauce, sau sauce, vineger,salt, black pepper, green chills and mix them well on low flames",
				"step 3: add cooked rice in the pan. cook for 5 mins."
						+ "step 4: add spring onions on the top and serve hot",
				140.84, ingredientList.get(3));
		Recipe r5 = new Recipe("paneer 65",
				"step1:  add ginger garlic paste , salt  to the paneer mix till its well coated the add flour, chilli powder and garam masala and some water for paste"
						+ "step 2:  heat oil  in pan then add paneer cubes , do not disturb for a mintue then flip and fry till golden brown and take them after frying",
				"step 3: add cumin seeds in the left over oil  then add  garlic , curry leaves and chillies  fry till it turn tasparent then add  3 spoon curd , chill powder and mix well until it becomes thick paste"
						+ "step 4: add paneer  and cook on high flame  till masala coats the paneer well then serve hot.",
				180.84, ingredientList.get(4));
		Recipe r6 = new Recipe("mutton kabab",
				"step 1: use mutton keema  then add flour, bream crumbs , salt,garam masala , coriander powder, onions, mint, coriander , green chillies ,lemon juice , giner garlic paste",
				"step 2: mix everything together. the mixture is firm not soggy and make tikks im equal size"
						+ "step 3:  fry them until  golden on medium flame" + "step 4: serve with any chutney.",
				240.04, ingredientList.get(5));
		Recipe r7 = new Recipe("pasta", "step 1:  boil 3 cups pasta  with salt  until it become soft"
				+ "step 2: In a pan  add cumin, garlic, fry for 2 mins then add onions , veggies cook it till it turns brown then add tomatoes  puree ,  chilli powder, garam masala fry for 3-4 mins till the raw flavour goes away",
				"step 3: add cooked pastes and cream if you want" + "step 4:  toss well and add coriander leaves",
				100.04, ingredientList.get(6));

		Recipe r8 = new Recipe("chicken fry",
				"step 1:  add All the spices, ginger  paste , salt, and lime juice to the chicken and mix them until the chicken is well coated. keep it aside for 2-3 hours"
						+ "step 2: heat oil for deep frying and add the chicken  pieces. fry them until golden brown",
				"step 3:  after frying take out the chicken in a plate" + "step 4: serve hot with rice  and curry",
				240.04, ingredientList.get(7));

		// r1.setIngredientsList(ingredient.getIngredientId([0]));

		recipeDao.registerRecipe(r1);
		recipeDao.registerRecipe(r2);

		recipeDao.registerRecipe(r3);
		recipeDao.registerRecipe(r4);
		recipeDao.registerRecipe(r5);
		recipeDao.registerRecipe(r6);
		recipeDao.registerRecipe(r7);
		recipeDao.registerRecipe(r8);

	}

	@RequestMapping("/getRecipe/{recipeId}")
	public Recipe getRecipeId(@PathVariable("recipeId") int recipeId) {
		Recipe recipeById = recipeDao.getRecipeById(recipeId);
		return recipeById;
	}

	@RequestMapping("/showAllRecipes")
	public List<Recipe> showAllRecipes() {
		List<Recipe> recipeList = recipeDao.getAllRecipes();
		return recipeList;

	}
	
	

}
