package com.ts;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.dao.OrdersDao;
import com.model.OrderDetails;

@RestController
public class OrderDetailsController {
	

	@Autowired
	OrdersDao ordersDao;
	
	@PostMapping("/registerOrderDetails")
	public String registerOrder(@RequestBody OrderDetails ordersDetails) {
		System.out.println("Data Received from Angular for Register customer");
		System.out.println(ordersDetails);

		 return "OrderDetails SuccessFul";
	}
	

}
