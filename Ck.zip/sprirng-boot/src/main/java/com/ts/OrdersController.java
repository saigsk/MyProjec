package com.ts;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dao.CustomerDao;
import com.dao.IngredientDao;
import com.dao.OrderDetailsDao;
import com.dao.OrdersDao;
import com.dao.RecipeDao;
import com.model.Orders;

@RestController
public class OrdersController {

	@Autowired
	OrdersDao ordersDao;

	@Autowired
	OrderDetailsDao ordersDetailsDao;

	@Autowired
	CustomerDao customerDao;

	@Autowired
	RecipeDao recipeDao;

	@Autowired
	IngredientDao ingredientDao;

	@PostMapping("/registerOrder")
	public String registerOrder(@RequestBody Orders orders) {
		/*
		 * List<Customer> customerList = customerDao.getAllCustomers(); List<Recipe>
		 * recipeList = recipeDao.getAllRecipes(); List<Ingredient> ingredientList =
		 * ingredientDao.getAllIngredients();
		 * 
		 * Orders o1 = new Orders("On The Way", new Date("06/03/2021"),
		 * customerList.get(0)); Orders o2 = new Orders("On The Way", new
		 * Date("06/03/2021"), customerList.get(1));
		 * 
		 * List<Orders> orderList = new ArrayList<Orders>(); orderList.add(o1);
		 * orderList.add(o2);
		 * 
		 * OrderDetails orderDetails = new OrderDetails(180.84, orderList.get(0),
		 * recipeList.subList(0, 1), ingredientList.subList(0, 2));
		 * 
		 * ordersDetailsDao.register(orderDetails);
		 * 
		 * ordersDao.registerOrder(orderList);
		 */
		
		System.out.println("Data Received from Angular for Register customer");
		System.out.println(orders);

		 return "Order SuccessFul";
	}

	@RequestMapping("/getAllOrders")
	public List<Orders> getAllOrders() {
		return ordersDao.getAllOrders();
	}

}
