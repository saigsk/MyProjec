package com.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class Recipe {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="recipeId")
	private int recipeId;
	private String recipeName;
	@Column(columnDefinition = "TEXT")
	private String instructions1;
	@Column(columnDefinition = "TEXT")
	private String instructions2;
	private double price;

	// recipe to ingredients
	@OneToOne
	@JoinColumn(name="ingredient_id")
	private Ingredient ingredients ;

	// recipe to orderdetails
	@ManyToOne
	@JoinColumn(name = "order_details_id")
	private OrderDetails orderDetails;

	// Recipe to orderDetails
	/*
	 * @OneToMany(mappedBy="recipe") List<OrderDetails> orderDetailsList = new
	 * ArrayList<OrderDetails>();
	 */

	public Recipe() {
		super();
	}

	/*
	 * public Recipe(String recipeName, String instructions1, String instructions2,
	 * double price, List<Ingredient> ingredientsList) { super(); this.recipeName =
	 * recipeName; this.instructions1 = instructions1; this.instructions2 =
	 * instructions2; this.price = price; this.ingredientsList = ingredientsList;
	 * this.orderDetails = orderDetails; }
	 */

	public Recipe(String recipeName, String instructions1, String instructions2,
			double price, Ingredient ingredients ) {
		super(); 
		// this.recipeId = recipeId;
		this.recipeName = recipeName;
		this.instructions1 = instructions1;
		this.instructions2 = instructions2;
		this.price = price;
		this.ingredients = ingredients;
	}

	public int getRecipeId() {
		return recipeId;
	}

	public void setRecipeId(int recipeId) {
		this.recipeId = recipeId;
	}

	public String getRecipeName() {
		return recipeName;
	}

	public void setRecipeName(String recipeName) {
		this.recipeName = recipeName;
	}

	public String getInstructions() {
		return instructions1;
	}

	public String getInstructions2() {
		return instructions2;
	}

	public void setInstructions2(String instructions2) {
		this.instructions2 = instructions2;
	}

	public void setInstructions(String instructions1) {
		this.instructions1 = instructions1;
	}

	public Ingredient getIngredientsList() {
		return ingredients;
	}

	public void setIngredientsList(Ingredient ingredients) {
		this.ingredients = ingredients;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public OrderDetails getOrderDetails() {
		return orderDetails;
	}

	public void setOrderDetails(OrderDetails orderDetails) {
		this.orderDetails = orderDetails;
	}

	@Override
	public String toString() {
		return "Recipe [recipeId=" + recipeId + ", recipeName=" + recipeName + ", instructions1=" + instructions1
				+ ", instructions2=" + instructions2 + ", price=" + price + ", ingredients=" + ingredients
				+ ", orderDetails=" + orderDetails + "]";
	}

	/*
	 * public OrderDetails getOrderDetails() { return orderDetails; }
	 * 
	 * public void setOrderDetails(OrderDetails orderDetails) { this.orderDetails =
	 * orderDetails; }
	 */

	/*
	 * public List<OrderDetails> getOrderDetailsList() { return orderDetailsList; }
	 * 
	 * public void setOrderDetailsList(List<OrderDetails> orderDetailsList) {
	 * this.orderDetailsList = orderDetailsList; }
	 */

}
