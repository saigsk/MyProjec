import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showallorders',
  templateUrl: './showallorders.component.html',
  styleUrls: ['./showallorders.component.css']
})
export class ShowallordersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
