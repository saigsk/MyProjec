import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-showallcustomers',
  templateUrl: './showallcustomers.component.html',
  styleUrls: ['./showallcustomers.component.css']
})
export class ShowallcustomersComponent implements OnInit {

  customers: any

  constructor(public customer: CustomerService) { }

  ngOnInit(): void {
    this.customer.getallcustomers().subscribe((data:any)=> {console.log(data), this.customers = data;});
  }

 
}
