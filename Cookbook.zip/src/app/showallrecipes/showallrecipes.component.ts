import { Component, OnInit } from '@angular/core';
import { RecipesService } from '../recipes.service';

@Component({
  selector: 'app-showallrecipes',
  templateUrl: './showallrecipes.component.html',
  styleUrls: ['./showallrecipes.component.css']
})
export class ShowallrecipesComponent implements OnInit {

  recipes : any;
  recipe: any;
  constructor(public recipees: RecipesService) {this.recipes = [
    {recipeId: 1001, recipeName: 'Aloo Fry', price: 100,  imagePath: 'assets/ImagesCook/AlooFry.jpg'},

    {recipeId: 1002, recipeName: 'Pasta', imagePath: 'assets/ImagesCook/Pasta.jpg', price: 189.99},
   
    {recipeId: 1003, recipeName: 'Chicken Fry', imagePath: 'assets/ImagesCook/ChickenFry.jpg' , price: 289.99},
   
    {recipeId: 1004, recipeName: 'Dal', price: 129.99, imagePath: 'assets/ImagesCook/Dal.jpg'},
   
    {recipeId: 1005, recipeName: 'Fried Rice', price: 139.99, imagePath: 'assets/ImagesCook/FriedRice.jpg'},
   
    {recipeId: 1006, recipeName: 'Kebabs', price: 299.99, imagePath: 'assets/ImagesCook/kebab.jpg'},

    {recipeId: 1007, recipeName: 'Chicken Noodles', price: 189.99, imagePath: 'assets/ImagesCook/Noodles.jpg'},

    {recipeId: 1008, recipeName: 'Paneer65', price: 129.99, imagePath: 'assets/ImagesCook/Paneer65.jpg'},

    {recipeId: 1009, recipeName: 'Gobi Manchuria', price: 149.99, imagePath: 'assets/ImagesCook/GobiManchuria.jpg'}
  ]; }

  ngOnInit(): void {
  }

  delete(recipe: any): void {

  }

  

 

}
