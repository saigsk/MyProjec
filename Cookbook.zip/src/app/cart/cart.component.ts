import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';
import { CustomerService } from '../customer.service';
import { of } from 'rxjs';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  cartItems = [];
  retrievedData: any;
  orders: any;
  orderDetails: any;
 // items = this.cartService.getItems();
  constructor(private service: CustomerService) {  
    this.cartItems = this.service.cartItems;
  }

  ngOnInit(): void {
    this.orders = {};
    this.orderDetails = {recipe: {}};
  }
  purchase() {
    this.service.purchase(this.cartItems).subscribe();
  }

}
