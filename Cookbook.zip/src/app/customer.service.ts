import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { retry } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  cartItems = [];
  productToBeAdded: Subject<any>;
  purchaseOrder: any;

  public isUserLogged:boolean;

  constructor(public httpClient:HttpClient) {
    this.isUserLogged=false;
    this.productToBeAdded = new Subject();

   }

   addToCart(recipe: any){
    this.productToBeAdded.next(recipe); // publishing
    this.cartItems.push();
  }

  getForCart() {
    return this.productToBeAdded.asObservable();
  }


  purchase(items: any) {
    // goes to rest api employee controller
   const endpoint = 'purchase';
   this.purchaseOrder = {
   orderId: 1,
   amount: 100.99,
   address: '10-20,east,hyd',
   customer: {custId: 1},
   orderDetails: items
   };
   // const formData: FormData = new FormData();
   // formData.append('items', JSON.stringify(items));
   // formData.append('userId', '100');
   return this.httpClient.post(endpoint, this.purchaseOrder);
 }
   public setUserLoggedIn():void{
    this.isUserLogged=true;
   }
   public getUserLoggedIn():any{
    return this.isUserLogged;
   }
   public setUserLoggedOut():void{
     this.isUserLogged=false;
   }
   public register(customer:any): any{
    return this.httpClient.post('registerCustomer',customer);
   }

   public getCustomer(loginId:any,password:any):any{
     return this.httpClient.get('getCustomer'+'/'+loginId+'/'+password);
   }

   public getallcustomers(): any{
     return this.httpClient.get('showAllCustomers')
   }
}
