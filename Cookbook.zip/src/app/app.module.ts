import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HeaderComponent } from './header/header.component';
import { RouterModule,Routes } from '@angular/router';
import { FooterComponent } from './footer/footer.component';
import { RecipeComponent } from './recipe/recipe.component';
import { AuthGuard } from './auth.guard';
import{HttpClientModule} from '@angular/common/http';
import { AdminheaderComponent } from './adminheader/adminheader.component';
import { ShowallcustomersComponent } from './showallcustomers/showallcustomers.component';
import { CartComponent } from './cart/cart.component';
import { HomeComponent } from './home/home.component';
import { ShowallordersComponent } from './showallorders/showallorders.component';
import { ShowallrecipesComponent } from './showallrecipes/showallrecipes.component';
const appRoot:Routes=[
  {path:'',component:HomeComponent},
  {path:'login',component:LoginComponent},
  {path:'register',component:RegisterComponent},
  {path:'recipe',canActivate:[AuthGuard],component:RecipeComponent},
  {path:'adminheader',canActivate:[AuthGuard],component:AdminheaderComponent},
  {path:'adminheader/showallcustomers',canActivate:[AuthGuard],component:ShowallcustomersComponent},
  {path:'adminheader/showallrecipes',canActivate:[AuthGuard],component:ShowallrecipesComponent},
  {path:'cart',canActivate:[AuthGuard],component:CartComponent},
  

];

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    HeaderComponent,
    FooterComponent,
    RecipeComponent,
    AdminheaderComponent,
    ShowallcustomersComponent,
    CartComponent,
    HomeComponent,
    ShowallordersComponent,
    ShowallrecipesComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot(appRoot),
    HttpClientModule,
    ToastrModule.forRoot(),
    BrowserAnimationsModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
