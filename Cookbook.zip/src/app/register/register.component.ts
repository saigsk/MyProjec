import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  
  constructor(public router:Router,public service:CustomerService,private toastr: ToastrService) { }

  ngOnInit(): void {
  }
  submitRegisterForm(registerForm:any):void{
   
   
    console.log(registerForm);
    this.service.register(registerForm).subscribe((result:any)=>console.log(result));
    this.router.navigate(['login']);

    

  }
  loginPage():void{
    this.router.navigate(['login']);

  }

  showToaster(){
    this.toastr.success("Register Successfully");
}


}
